import os
import matplotlib.pyplot as plt

# === Your data here ===
x = [4,5,6,7,8,9,10,11,12]  # e.g., total k-points (Nk = nx×ny×nz)
y = []
for k_grid in x:
    with open(f'{k_grid}/aims.out', 'r') as f:
        for line in f:
            if '| Total energy of the DFT / Hartree-Fock s.c.f. calculation' in line:
                y.append(float(line.split()[-2]))

# how to plot the derivative of the energy with respect to the k-grid?
#   1. calculate the derivative of the energy with respect to the k-grid
#   2. plot the derivative of the energy with respect to the k-grid
# === Plotting ===
y = [i - min(y) for i in y]
y_derivative = [y[i+1] - y[i] for i in range(len(y)-1)]
x_derivative = x[:-1]
plt.plot(x_derivative, y_derivative, marker='o', linestyle='-', linewidth=1.5)
plt.xlabel('k-grid')
plt.ylabel('dE/dn (eV)')
plt.title('k-grid Convergence')
plt.grid(True)
plt.tight_layout()
plt.savefig('kgrid_simple_derivative.png', dpi=150)

