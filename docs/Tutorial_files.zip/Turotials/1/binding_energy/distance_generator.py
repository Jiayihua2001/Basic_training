from ase import Atoms
from ase.io import write
import numpy as np
from pathlib import Path
import os

submit_path = os.path.abspath("submit.sh")
control_path = os.path.abspath("control.in")
# Output directory
output_dir = Path("H2_binding_energy")
output_dir.mkdir(exist_ok=True)
# Bond distances from 0.5 to 1.0 Å in steps of 0.1
distances = np.arange(0.5, 1.0, 0.1)
for d in distances:
    h2 = Atoms('H2', positions=[[0, 0, 0], [0, 0, d]], cell=[6, 6, 6], pbc=False)
    sub_path = output_dir / f"H2_{d:.1f}"
    sub_path.mkdir(exist_ok=True)
    write(sub_path / "geometry.in", h2, format='aims')
    os.system(f"cp {submit_path} {sub_path}")
    os.system(f"cp {control_path} {sub_path}")
    print(f"Saved: {sub_path}")

