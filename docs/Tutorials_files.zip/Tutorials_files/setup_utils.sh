#!/bin/bash
#
# setup_utils.sh - Set up utility scripts in your home directory
#
# This script copies the 5 essential utility scripts to your home directory (~/)
# so you can run them from any working directory using ~/script_name.
#
# Usage:
#   bash setup_utils.sh trace    # If you are on Trace HPC
#   bash setup_utils.sh arjuna   # If you are on Arjuna HPC
#
# After running this script, the following files will be available in ~/
#
# Files installed:
#   ~/write_control.py  - Generates control.in files for FHI-aims calculations.
#                         Reads species defaults and creates properly formatted
#                         control.in with the correct basis set settings.
#                         Usage: python ~/write_control.py --elements Si
#                                python ~/write_control.py --input_geometry --species_default light
#
#   ~/submit.sh         - SLURM batch script for submitting FHI-aims jobs on HPC.
#                         Pre-configured with the correct paths to the FHI-aims binary
#                         and appropriate resource settings for your cluster.
#                         Usage: sbatch ~/submit.sh
#                                cp ~/submit.sh .  (copy to working dir for automation scripts)
#
#   ~/Automation.py     - Automation helper for Tutorial 2 (Periodic Systems).
#                         Automates k-point convergence tests, lattice constant scans,
#                         and plotting for Si, Na, Fe, and Ge calculations.
#                         Usage: python ~/Automation.py --make_k_grid
#                                python ~/Automation.py --plot_k_grid
#                                python ~/Automation.py --Fe_grid_search --lattice_type bcc
#
#   ~/Surfaces.py       - Automation helper for Tutorial 3 (2D Materials & Surfaces).
#                         Builds bilayer graphene, manages stacking configurations,
#                         runs vacuum/k-point convergence, distance scans, and
#                         TCNQ adsorption on graphene.
#                         Usage: python ~/Surfaces.py --build_bilayer --stacking AA
#                                python ~/Surfaces.py --make_k_grid_2d
#                                python ~/Surfaces.py --place_tcnq_on_graphene --tcnq_site hollow
#
#   ~/aimsplot.py       - Plots band structure and DOS from an FHI-aims run.
#                         Reads band*.out and KS_DOS_total.dat files to generate
#                         combined band structure and DOS plots.
#                         Usage: python ~/aimsplot.py
#                                python ~/aimsplot.py --Emin -15 --Emax 10 --no-legend
#                                python ~/aimsplot.py --help
#

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Check argument
if [ -z "$1" ]; then
    echo "Error: Please specify your HPC cluster."
    echo "Usage: bash setup_utils.sh trace"
    echo "       bash setup_utils.sh arjuna"
    exit 1
fi

HPC="$1"

if [ "$HPC" != "trace" ] && [ "$HPC" != "arjuna" ]; then
    echo "Error: Unknown HPC '$HPC'. Please use 'trace' or 'arjuna'."
    exit 1
fi

echo "Setting up utility scripts for $HPC..."

# 1. write_control.py - Generates control.in for FHI-aims
echo "  Copying write_control.py ($HPC version)..."
cp "$SCRIPT_DIR/utils/$HPC/write_control.py" ~/write_control.py

# 2. submit.sh - SLURM batch script for FHI-aims
echo "  Copying submit.sh ($HPC version)..."
cp "$SCRIPT_DIR/utils/$HPC/submit.sh" ~/submit.sh

# 3. Automation.py - Tutorial 2 automation (k-grid, lattice scans, plotting)
echo "  Copying Automation.py..."
cp "$SCRIPT_DIR/Tutorial_2/Automation.py" ~/Automation.py

# 4. Surfaces.py - Tutorial 3 automation (bilayer, surfaces, adsorption)
echo "  Copying Surfaces.py..."
cp "$SCRIPT_DIR/Tutorial_3/Surfaces.py" ~/Surfaces.py

# 5. aimsplot.py - Band structure and DOS plotting
echo "  Copying aimsplot.py..."
cp "$SCRIPT_DIR/Tutorial_2/aimsplot.py" ~/aimsplot.py

echo ""
echo "Done! The following files are now in your home directory:"
echo "  ~/write_control.py  - Generate control.in files"
echo "  ~/submit.sh         - SLURM job submission script"
echo "  ~/Automation.py     - Tutorial 2 automation (periodic systems)"
echo "  ~/Surfaces.py       - Tutorial 3 automation (2D materials & surfaces)"
echo "  ~/aimsplot.py       - Band structure and DOS plotting"
echo ""
echo "You can now use them from any directory, e.g.:"
echo "  python ~/write_control.py --elements Si"
echo "  sbatch ~/submit.sh"
echo "  python ~/Automation.py --make_k_grid"
echo "  python ~/Surfaces.py --build_bilayer --stacking AA"
echo "  python ~/aimsplot.py"
