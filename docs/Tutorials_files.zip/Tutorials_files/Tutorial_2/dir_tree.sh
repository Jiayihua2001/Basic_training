#!/bin/sh

# Make Silicon and Sodium directories
mkdir Si_Na
mkdir Si_Na/Si
mkdir Si_Na/Si/kpts
mkdir Si_Na/Si/relax
mkdir Si_Na/Si/band
mkdir Si_Na/Na
mkdir Si_Na/Na/kpts
mkdir Si_Na/Na/relax
mkdir Si_Na/Na/band

# Make Iron directories
mkdir Fe
mkdir Fe/LDA
mkdir Fe/LDA/BCC
mkdir Fe/LDA/BCC/kpts
mkdir Fe/LDA/BCC/mag
mkdir Fe/LDA/BCC/non-mag
mkdir Fe/LDA/FCC
mkdir Fe/LDA/FCC/kpts
mkdir Fe/LDA/FCC/mag
mkdir Fe/LDA/FCC/non-mag
mkdir Fe/PBE
mkdir Fe/PBE/BCC
mkdir Fe/PBE/BCC/kpts
mkdir Fe/PBE/BCC/mag
mkdir Fe/PBE/BCC/mag/band
mkdir Fe/PBE/BCC/non-mag
mkdir Fe/PBE/FCC
mkdir Fe/PBE/FCC/kpts
mkdir Fe/PBE/FCC/mag
mkdir Fe/PBE/FCC/non-mag

# Make Germanium directories
mkdir Ge
mkdir Ge/LDA
mkdir Ge/LDA/kpts
mkdir Ge/LDA/relax
mkdir Ge/LDA/band
mkdir Ge/PBE
mkdir Ge/PBE/kpts
mkdir Ge/PBE/relax
mkdir Ge/PBE/band
mkdir Ge/SCAN
mkdir Ge/SCAN/kpts
mkdir Ge/SCAN/relax
mkdir Ge/SCAN/band
mkdir Ge/HSE06
mkdir Ge/HSE06/kpts
mkdir Ge/HSE06/relax
mkdir Ge/HSE06/band
