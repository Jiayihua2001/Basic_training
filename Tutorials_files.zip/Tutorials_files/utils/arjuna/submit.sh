#!/bin/bash
#SBATCH -J relaxation# Job name
#SBATCH -N 1 # Number of nodes
#SBATCH -n 54 # Number of total cores
#SBATCH -o job_%j.out # File to which STDOUT will be written %j is the job #
#SBATCH -p cpu
#SBATCH --ntasks-per-node=54 # Requests 1 tasks per node.
#SBATCH --time=2:00:00


ulimit -s unlimited
ulimit -v unlimited

# Directory for aims binary and the env
AIMS_DIR="/home/27735A_group/shared/bin"
AIMS_BIN="$AIMS_DIR/aims.221103.scalapack.mpi.x"
AIMS_ENV="$AIMS_DIR/aims_env.sh"

source $AIMS_ENV

export OMP_NUM_THREADS=1

mpirun -np 54  $AIMS_BIN > aims.out



